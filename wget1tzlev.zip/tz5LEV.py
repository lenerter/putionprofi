vasa_money=float(input("Сколько денег у васи? "))
frend_dolg_money=float(input("Сколько он должен другу? "))
traner_dolg_money=float(input("Сколько он должен тренеру? "))
vasa_money_now=vasa_money-(frend_dolg_money+traner_dolg_money)
print(vasa_money_now)









