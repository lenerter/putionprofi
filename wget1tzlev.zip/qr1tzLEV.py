import pyqrcode
import png

text = input("Введите текст: ")
s = input("Введите размер qrcode: ")
my_qr = pyqrcode.create(text)
my_qr.png('qr1.png',scale=s)
print('QR-код сгенерирован')
print(my_qr.text())
