n1=float(input("напиши соклько нашол 1 "))
n2=float(input("напиши соклько нашол 2 "))
n3=float(input("напиши соклько нашол 3 "))
n4=float(input("Сколько стоит морожное "))
suma=(n1+n2+n3)
if suma > n4:
    print("хватает")
    print("Осталось денег:",(n1+n2+n3)-n4,)
elif suma < n4:
    print("нехватает",n4-(n1+n2+n3))






