import pyshorteners
url=input("Введите сылку______________________________________________________________")
s = pyshorteners.Shortener()
print(s.tinyurl.short(url))
print(s.cuttly.short(url))
print(s.dagd.short(url))
print(s.gitio.short(url))