import wget
# import ssl

def tets():
    year = 2020
    url = f'https://www.mos.ru/upload/newsfeed/presspresentations/otchet_{year}.pdf'
    wget.download(url)
    print('Good')

tets()